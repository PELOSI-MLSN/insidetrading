import { Lightbulb, ArrowRight, TrendingDown } from 'lucide-react';
import type { TradeData, AnalysisResult } from '../App';

interface CounterfactualExplanationProps {
  tradeData: TradeData;
  analysis: AnalysisResult;
}

interface Counterfactual {
  feature: string;
  currentValue: string;
  suggestedValue: string;
  impact: string;
  suspicionReduction: number;
}

export function CounterfactualExplanation({ tradeData, analysis }: CounterfactualExplanationProps) {
  // Only show if trade is suspicious
  if (analysis.suspicionCategory === 'Not Suspicious') {
    return null;
  }

  const counterfactuals = generateCounterfactuals(tradeData, analysis);

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-xl p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-amber-500/10 rounded-lg">
          <Lightbulb className="w-6 h-6 text-amber-400" />
        </div>
        <div>
          <h3 className="text-slate-100">What Would Make This Trade Less Suspicious?</h3>
          <p className="text-slate-400 text-sm">
            Understanding the model's reasoning through counterfactual analysis
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {counterfactuals.map((cf, index) => (
          <div 
            key={index}
            className="bg-slate-800/50 border border-slate-700 rounded-lg p-4"
          >
            <div className="flex items-start gap-3 mb-3">
              <TrendingDown className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-slate-300 mb-2">{cf.feature}</p>
                
                <div className="flex items-center gap-3 mb-3 flex-wrap">
                  <div className="bg-red-950/30 border border-red-900/50 rounded px-3 py-1.5">
                    <p className="text-xs text-red-400 mb-0.5">Current</p>
                    <p className="text-slate-200">{cf.currentValue}</p>
                  </div>
                  
                  <ArrowRight className="w-4 h-4 text-slate-600" />
                  
                  <div className="bg-green-950/30 border border-green-900/50 rounded px-3 py-1.5">
                    <p className="text-xs text-green-400 mb-0.5">Suggested</p>
                    <p className="text-slate-200">{cf.suggestedValue}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-2">
                  <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-green-600 to-green-500"
                      style={{ width: `${cf.suspicionReduction}%` }}
                    />
                  </div>
                  <span className="text-sm text-green-400 whitespace-nowrap">
                    -{cf.suspicionReduction}%
                  </span>
                </div>

                <p className="text-slate-400 text-sm">
                  {cf.impact}
                </p>
              </div>
            </div>
          </div>
        ))}

        <div className="bg-blue-950/20 border border-blue-900/30 rounded-lg p-4 mt-4">
          <p className="text-blue-300 text-sm">
            <strong>How to read this:</strong> These scenarios show what aspects of the trade are 
            driving the suspicion score. If multiple features were adjusted to normal ranges, 
            the trade would likely be classified as "Not Suspicious."
          </p>
        </div>
      </div>
    </div>
  );
}

function generateCounterfactuals(tradeData: TradeData, analysis: AnalysisResult): Counterfactual[] {
  const counterfactuals: Counterfactual[] = [];
  const { calculatedFeatures } = analysis;

  // Trade Size Relative to Owned
  if (calculatedFeatures.tradeSizeRelativeToOwned > 0.15) {
    const current = (calculatedFeatures.tradeSizeRelativeToOwned * 100).toFixed(1) + '%';
    const normalThreshold = 10;
    const targetQty = Math.floor(tradeData.owned * 0.10);
    
    counterfactuals.push({
      feature: 'Trade Size Relative to Owned Shares',
      currentValue: current,
      suggestedValue: `≤${normalThreshold}% (≈${targetQty.toLocaleString()} shares)`,
      impact: `If the trade size were under ${normalThreshold}% of owned shares, suspicion would drop significantly. Large trades relative to holdings are unusual and often scrutinized.`,
      suspicionReduction: calculatedFeatures.tradeSizeRelativeToOwned > 0.5 ? 60 : 
                         calculatedFeatures.tradeSizeRelativeToOwned > 0.3 ? 40 : 25
    });
  }

  // Change in Ownership
  if (Math.abs(calculatedFeatures.changeInOwnership) > 15) {
    const current = calculatedFeatures.changeInOwnership.toFixed(1) + '%';
    const isIncrease = calculatedFeatures.changeInOwnership > 0;
    
    counterfactuals.push({
      feature: 'Change in Ownership (δown)',
      currentValue: current,
      suggestedValue: '≤15% change',
      impact: `Drastic ${isIncrease ? 'increases' : 'decreases'} in ownership percentage raise red flags. If the change in ownership were under 15%, this trade would likely be classified as routine.`,
      suspicionReduction: Math.abs(calculatedFeatures.changeInOwnership) > 50 ? 50 : 
                         Math.abs(calculatedFeatures.changeInOwnership) > 30 ? 35 : 20
    });
  }

  // Trade Direction (if Sell)
  if (calculatedFeatures.tradeDirection === 'Sell') {
    counterfactuals.push({
      feature: 'Trade Direction',
      currentValue: 'Sell',
      suggestedValue: 'Buy or Award',
      impact: 'Sales by insiders are scrutinized more heavily than purchases, as they may indicate non-public knowledge of negative developments. Purchases typically reduce suspicion by 15-20%.',
      suspicionReduction: 18
    });
  }

  // Trade Value
  if (calculatedFeatures.value > 1000000) {
    const currentValue = '$' + calculatedFeatures.value.toLocaleString();
    
    counterfactuals.push({
      feature: 'Trade Value',
      currentValue: currentValue,
      suggestedValue: '≤$500,000',
      impact: 'Very high-value trades attract attention. Keeping transaction values under $500K would reduce suspicion as they represent more typical insider activity.',
      suspicionReduction: calculatedFeatures.value > 5000000 ? 25 : 15
    });
  }

  // Price extremes
  if (tradeData.price > 500 || tradeData.price < 5) {
    const current = '$' + tradeData.price.toFixed(2);
    
    counterfactuals.push({
      feature: 'Share Price',
      currentValue: current,
      suggestedValue: '$20-$200 (typical range)',
      impact: tradeData.price > 500 
        ? 'Extremely high share prices can indicate unusual circumstances. Trades in the $20-$200 range are more common and less suspicious.'
        : 'Very low share prices (penny stocks) are often associated with higher manipulation risk. Mid-range prices reduce suspicion.',
      suspicionReduction: 12
    });
  }

  // If no major counterfactuals, add a combined one
  if (counterfactuals.length === 0) {
    counterfactuals.push({
      feature: 'Multiple Small Adjustments',
      currentValue: 'Current pattern',
      suggestedValue: 'Smaller trade size + longer time horizon',
      impact: 'While no single feature is extreme, the combination creates moderate suspicion. Breaking this into smaller trades over time would reduce scrutiny.',
      suspicionReduction: 30
    });
  }

  return counterfactuals.slice(0, 4); // Limit to top 4 suggestions
}
