import { TrendingUp, TrendingDown, ArrowRight, DollarSign, Percent, AlertCircle, CheckCircle, Info } from 'lucide-react';
import type { TradeData } from '../App';

interface FeatureBreakdownProps {
  calculatedFeatures: {
    tradeSizeRelativeToOwned: number;
    tradeDirection: string;
    value: number;
    changeInOwnership: number;
  };
  featureContributions: Array<{
    name: string;
    value: string | number;
    contribution: number;
  }>;
  tradeData: TradeData;
}

interface FeatureInfo {
  normalRange: string;
  whyItMatters: string;
  isUnusual: boolean;
  status: 'normal' | 'elevated' | 'extreme';
}

export function FeatureBreakdown({ 
  calculatedFeatures, 
  featureContributions,
  tradeData 
}: FeatureBreakdownProps) {
  const isBuy = calculatedFeatures.tradeDirection === 'Buy';
  const isSell = calculatedFeatures.tradeDirection === 'Sell';

  // Analyze each feature
  const tradeSizeInfo = analyzeTradeSize(calculatedFeatures.tradeSizeRelativeToOwned);
  const ownershipChangeInfo = analyzeOwnershipChange(calculatedFeatures.changeInOwnership);
  const tradeValueInfo = analyzeTradeValue(calculatedFeatures.value);
  const tradeDirectionInfo = analyzeTradeDirection(calculatedFeatures.tradeDirection);

  const getStatusIcon = (status: string) => {
    if (status === 'extreme') return <AlertCircle className="w-4 h-4 text-red-400" />;
    if (status === 'elevated') return <AlertCircle className="w-4 h-4 text-yellow-400" />;
    return <CheckCircle className="w-4 h-4 text-green-400" />;
  };

  const getStatusColor = (status: string) => {
    if (status === 'extreme') return 'text-red-400';
    if (status === 'elevated') return 'text-yellow-400';
    return 'text-green-400';
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-xl p-6">
      <h3 className="text-slate-100 mb-4">Feature Analysis with Context</h3>

      {/* Calculated Features Summary */}
      <div className="space-y-4 mb-6 pb-6 border-b border-slate-700">
        {/* Trade Direction */}
        <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-200">Trade Direction</span>
            <div className="flex items-center gap-2">
              {isBuy ? (
                <TrendingUp className="w-5 h-5 text-green-400" />
              ) : isSell ? (
                <TrendingDown className="w-5 h-5 text-red-400" />
              ) : (
                <ArrowRight className="w-5 h-5 text-slate-400" />
              )}
              <span className={`text-lg ${
                isBuy ? 'text-green-300' : isSell ? 'text-red-300' : 'text-slate-200'
              }`}>
                {calculatedFeatures.tradeDirection}
              </span>
              {getStatusIcon(tradeDirectionInfo.status)}
            </div>
          </div>
          <p className="text-xs text-slate-400 mb-2">
            {tradeData.tradeType}
          </p>
          
          <div className="bg-slate-900/30 rounded p-2 space-y-1.5 opacity-60">
            <div className="flex items-start gap-1.5">
              <Info className="w-3 h-3 text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="text-blue-300 mb-0.5">Why This Matters:</p>
                <p className="text-slate-400 text-xs leading-relaxed">{tradeDirectionInfo.whyItMatters}</p>
              </div>
            </div>
            <div className="text-xs pt-1.5 border-t border-slate-700/50">
              <p className="text-slate-500">Normal Pattern: <span className="text-slate-300">{tradeDirectionInfo.normalRange}</span></p>
              <p className={`mt-0.5 ${getStatusColor(tradeDirectionInfo.status)}`}>
                This Trade: {tradeDirectionInfo.isUnusual ? '🚩 Unusual' : '✓ Normal'}
              </p>
            </div>
          </div>
        </div>

        {/* Trade Size Relative to Owned */}
        <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-200">Trade Size / Owned</span>
            <div className="flex items-center gap-2">
              <span className="text-slate-100 text-lg">
                {(calculatedFeatures.tradeSizeRelativeToOwned * 100).toFixed(2)}%
              </span>
              {getStatusIcon(tradeSizeInfo.status)}
            </div>
          </div>
          <div className="mt-2 mb-3 h-2 bg-slate-700 rounded-full overflow-hidden">
            <div 
              className={`h-full ${
                calculatedFeatures.tradeSizeRelativeToOwned > 0.5 
                  ? 'bg-red-500' 
                  : calculatedFeatures.tradeSizeRelativeToOwned > 0.3
                  ? 'bg-yellow-500'
                  : 'bg-green-500'
              }`}
              style={{ width: `${Math.min(calculatedFeatures.tradeSizeRelativeToOwned * 100, 100)}%` }}
            />
          </div>
          
          <div className="bg-slate-900/30 rounded p-2 space-y-1.5 opacity-60">
            <div className="flex items-start gap-1.5">
              <Info className="w-3 h-3 text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="text-blue-300 mb-0.5">Why This Matters:</p>
                <p className="text-slate-400 text-xs leading-relaxed">{tradeSizeInfo.whyItMatters}</p>
              </div>
            </div>
            <div className="text-xs pt-1.5 border-t border-slate-700/50">
              <p className="text-slate-500">Typical Range: <span className="text-slate-300">{tradeSizeInfo.normalRange}</span></p>
              <p className={`mt-0.5 ${getStatusColor(tradeSizeInfo.status)}`}>
                This Trade: {(calculatedFeatures.tradeSizeRelativeToOwned * 100).toFixed(1)}% 
                {tradeSizeInfo.isUnusual ? ' 🚩 Extreme outlier' : ' ✓ Within normal range'}
              </p>
            </div>
          </div>
        </div>

        {/* Change in Ownership */}
        <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-200">Change in Ownership (δown)</span>
            <div className="flex items-center gap-2">
              <Percent className="w-5 h-5 text-purple-400" />
              <span className={`text-lg ${
                calculatedFeatures.changeInOwnership > 0 ? 'text-green-300' : 'text-red-300'
              }`}>
                {calculatedFeatures.changeInOwnership > 0 ? '+' : ''}
                {calculatedFeatures.changeInOwnership.toFixed(2)}%
              </span>
              {getStatusIcon(ownershipChangeInfo.status)}
            </div>
          </div>
          <p className="text-xs text-slate-400 mb-2">
            Relative to currently owned shares
          </p>
          
          <div className="bg-slate-900/30 rounded p-2 space-y-1.5 opacity-60">
            <div className="flex items-start gap-1.5">
              <Info className="w-3 h-3 text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="text-blue-300 mb-0.5">Why This Matters:</p>
                <p className="text-slate-400 text-xs leading-relaxed">{ownershipChangeInfo.whyItMatters}</p>
              </div>
            </div>
            <div className="text-xs pt-1.5 border-t border-slate-700/50">
              <p className="text-slate-500">Typical Change: <span className="text-slate-300">{ownershipChangeInfo.normalRange}</span></p>
              <p className={`mt-0.5 ${getStatusColor(ownershipChangeInfo.status)}`}>
                This Trade: {Math.abs(calculatedFeatures.changeInOwnership).toFixed(1)}% 
                {ownershipChangeInfo.isUnusual ? ' 🚩 Extreme outlier' : ' ✓ Within normal range'}
              </p>
            </div>
          </div>
        </div>

        {/* Trade Value */}
        <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-200">Trade Value</span>
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-blue-400" />
              <span className="text-slate-100 text-lg">
                ${calculatedFeatures.value.toLocaleString(undefined, { 
                  minimumFractionDigits: 2, 
                  maximumFractionDigits: 2 
                })}
              </span>
              {getStatusIcon(tradeValueInfo.status)}
            </div>
          </div>
          <p className="text-xs text-slate-400 mb-2">
            {Math.abs(tradeData.qty).toLocaleString()} shares × ${tradeData.price.toFixed(2)}
          </p>
          
          <div className="bg-slate-900/30 rounded p-2 space-y-1.5 opacity-60">
            <div className="flex items-start gap-1.5">
              <Info className="w-3 h-3 text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="text-blue-300 mb-0.5">Why This Matters:</p>
                <p className="text-slate-400 text-xs leading-relaxed">{tradeValueInfo.whyItMatters}</p>
              </div>
            </div>
            <div className="text-xs pt-1.5 border-t border-slate-700/50">
              <p className="text-slate-500">Expected Range: <span className="text-slate-300">{tradeValueInfo.normalRange}</span></p>
              <p className={`mt-0.5 ${getStatusColor(tradeValueInfo.status)}`}>
                This Trade: ${calculatedFeatures.value.toLocaleString()} 
                {tradeValueInfo.isUnusual ? ' 🚩 High value' : ' ✓ Normal value'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Contributions */}
      <div>
        <h4 className="text-slate-300 mb-3">Feature Contributions to Suspicion Score</h4>
        <div className="space-y-2">
          {featureContributions.map((feature, index) => (
            <div key={index} className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">{feature.name}</span>
                <span className="text-slate-300">{feature.value}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-600 to-blue-500"
                    style={{ width: `${(feature.contribution / 0.3) * 100}%` }}
                  />
                </div>
                <span className="text-xs text-slate-500 w-12 text-right">
                  {(feature.contribution * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Analysis functions
function analyzeTradeSize(ratio: number): FeatureInfo {
  const percent = ratio * 100;
  return {
    normalRange: '3–10% of owned shares',
    whyItMatters: 'Large trades relative to current holdings are unusual. Insiders typically trade smaller portions to avoid market impact and regulatory scrutiny. Selling a large percentage suggests urgency or non-public information.',
    isUnusual: ratio > 0.15,
    status: ratio > 0.5 ? 'extreme' : ratio > 0.15 ? 'elevated' : 'normal'
  };
}

function analyzeOwnershipChange(changePercent: number): FeatureInfo {
  const absChange = Math.abs(changePercent);
  return {
    normalRange: '3–10% change',
    whyItMatters: 'Drastic changes in ownership percentage indicate significant shifts in an insider\'s stake. Large increases or decreases can signal confidence changes or material non-public information about the company\'s prospects.',
    isUnusual: absChange > 15,
    status: absChange > 50 ? 'extreme' : absChange > 15 ? 'elevated' : 'normal'
  };
}

function analyzeTradeValue(value: number): FeatureInfo {
  return {
    normalRange: '$50K–$500K',
    whyItMatters: 'High-value transactions attract regulatory attention and are more likely to impact stock prices. Multi-million dollar trades are less common and often correlate with major corporate events or insider knowledge.',
    isUnusual: value > 1000000,
    status: value > 5000000 ? 'extreme' : value > 1000000 ? 'elevated' : 'normal'
  };
}

function analyzeTradeDirection(direction: string): FeatureInfo {
  const isSell = direction === 'Sell';
  return {
    normalRange: 'Buys and awards (60%), Sales (40%)',
    whyItMatters: isSell 
      ? 'Sales receive higher scrutiny than purchases because insiders selling may have negative non-public information. However, sales can also be for legitimate reasons like diversification or liquidity needs.'
      : 'Purchases are generally viewed favorably as they indicate insider confidence in the company. Awards and grants are routine compensation.',
    isUnusual: isSell,
    status: isSell ? 'elevated' : 'normal'
  };
}