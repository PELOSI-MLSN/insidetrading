import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select } from './ui/select';
import { TrendingUp, Calendar } from 'lucide-react';
import type { TradeData } from '../App';

interface TradeInputFormProps {
  onSubmit: (tradeData: TradeData) => void;
}

export function TradeInputForm({ onSubmit }: TradeInputFormProps) {
  const [formData, setFormData] = useState({
    companyName: '',
    ticker: '',
    price: '',
    qty: '',
    owned: '',
    tradeType: 'P - Purchase',
    tradeDate: new Date().toISOString().split('T')[0],
    insiderName: '',
    insiderTitle: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.companyName || !formData.ticker || !formData.price || !formData.qty || !formData.owned) {
      alert('Please fill in all required fields');
      return;
    }

    const tradeData: TradeData = {
      id: Date.now().toString(),
      companyName: formData.companyName,
      ticker: formData.ticker.toUpperCase(),
      price: parseFloat(formData.price),
      qty: parseFloat(formData.qty),
      owned: parseFloat(formData.owned),
      tradeType: formData.tradeType,
      tradeDate: formData.tradeDate,
      insiderName: formData.insiderName || undefined,
      insiderTitle: formData.insiderTitle || undefined
    };

    onSubmit(tradeData);
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Company Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="companyName" className="text-slate-300">
            Company Name <span className="text-red-400">*</span>
          </Label>
          <Input
            id="companyName"
            value={formData.companyName}
            onChange={(e) => handleChange('companyName', e.target.value)}
            placeholder="e.g., Apple Inc."
            className="bg-slate-800/50 border-slate-700 text-slate-100 placeholder:text-slate-500"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="ticker" className="text-slate-300">
            Ticker Symbol <span className="text-red-400">*</span>
          </Label>
          <Input
            id="ticker"
            value={formData.ticker}
            onChange={(e) => handleChange('ticker', e.target.value.toUpperCase())}
            placeholder="e.g., AAPL"
            className="bg-slate-800/50 border-slate-700 text-slate-100 placeholder:text-slate-500"
            required
          />
        </div>
      </div>

      {/* Trade Details */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="price" className="text-slate-300">
            Price per Share ($) <span className="text-red-400">*</span>
          </Label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">$</span>
            <Input
              id="price"
              type="number"
              step="0.01"
              value={formData.price}
              onChange={(e) => handleChange('price', e.target.value)}
              placeholder="0.00"
              className="bg-slate-800/50 border-slate-700 text-slate-100 placeholder:text-slate-500 pl-7"
              required
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="qty" className="text-slate-300">
            Quantity (shares) <span className="text-red-400">*</span>
          </Label>
          <Input
            id="qty"
            type="number"
            value={formData.qty}
            onChange={(e) => handleChange('qty', e.target.value)}
            placeholder="Use negative for sales"
            className="bg-slate-800/50 border-slate-700 text-slate-100 placeholder:text-slate-500"
            required
          />
          <p className="text-slate-500 text-xs">Negative values for sales</p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="owned" className="text-slate-300">
            Currently Owned <span className="text-red-400">*</span>
          </Label>
          <Input
            id="owned"
            type="number"
            value={formData.owned}
            onChange={(e) => handleChange('owned', e.target.value)}
            placeholder="Total shares owned"
            className="bg-slate-800/50 border-slate-700 text-slate-100 placeholder:text-slate-500"
            required
          />
        </div>
      </div>

      {/* Trade Type and Date */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="tradeType" className="text-slate-300">
            Trade Type <span className="text-red-400">*</span>
          </Label>
          <select
            id="tradeType"
            value={formData.tradeType}
            onChange={(e) => handleChange('tradeType', e.target.value)}
            className="w-full px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-md text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="P - Purchase">P - Purchase</option>
            <option value="S - Sale">S - Sale</option>
            <option value="A - Award">A - Award</option>
            <option value="M - Option Exercise">M - Option Exercise</option>
            <option value="G - Gift">G - Gift</option>
            <option value="F - Tax">F - Tax</option>
            <option value="C - Conversion">C - Conversion</option>
            <option value="I - Discretionary">I - Discretionary</option>
          </select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="tradeDate" className="text-slate-300">
            Trade Date <span className="text-red-400">*</span>
          </Label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <Input
              id="tradeDate"
              type="date"
              value={formData.tradeDate}
              onChange={(e) => handleChange('tradeDate', e.target.value)}
              className="bg-slate-800/50 border-slate-700 text-slate-100 pl-10"
              required
            />
          </div>
        </div>
      </div>

      {/* Optional Insider Info */}
      <div className="border-t border-slate-700 pt-4">
        <p className="text-slate-400 mb-4">Optional Insider Information</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="insiderName" className="text-slate-300">
              Insider Name
            </Label>
            <Input
              id="insiderName"
              value={formData.insiderName}
              onChange={(e) => handleChange('insiderName', e.target.value)}
              placeholder="e.g., John Smith"
              className="bg-slate-800/50 border-slate-700 text-slate-100 placeholder:text-slate-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="insiderTitle" className="text-slate-300">
              Title/Position
            </Label>
            <Input
              id="insiderTitle"
              value={formData.insiderTitle}
              onChange={(e) => handleChange('insiderTitle', e.target.value)}
              placeholder="e.g., CEO, CFO, Director"
              className="bg-slate-800/50 border-slate-700 text-slate-100 placeholder:text-slate-500"
            />
          </div>
        </div>
      </div>

      {/* Calculated Fields Info */}
      <div className="bg-slate-800/30 border border-slate-700 rounded-lg p-4">
        <div className="flex items-start gap-2">
          <TrendingUp className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-slate-300 mb-1">Auto-calculated Features</p>
            <p className="text-slate-500 text-sm">
              The following will be calculated automatically: Trade Size Relative to Owned, 
              Change in Ownership (δown), Trade Direction, and Trade Value.
            </p>
          </div>
        </div>
      </div>

      {/* Submit Button */}
      <Button 
        type="submit"
        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
      >
        Analyze Trade
      </Button>
    </form>
  );
}
