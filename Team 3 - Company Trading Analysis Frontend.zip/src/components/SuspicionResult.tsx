import { AlertTriangle, Shield, CheckCircle } from 'lucide-react';

interface SuspicionResultProps {
  companyName: string;
  ticker: string;
  suspicionProbability: number;
  suspicionCategory: 'Highly Suspicious' | 'Potentially Suspicious' | 'Not Suspicious';
}

export function SuspicionResult({ 
  companyName, 
  ticker,
  suspicionProbability, 
  suspicionCategory 
}: SuspicionResultProps) {
  const getRiskConfig = () => {
    if (suspicionCategory === 'Highly Suspicious') {
      return {
        icon: AlertTriangle,
        color: 'red',
        bgGradient: 'from-red-950/50 to-red-900/30',
        borderColor: 'border-red-900/50',
        iconColor: 'text-red-400',
        textColor: 'text-red-300',
        scoreColor: 'text-red-400',
        label: 'CRITICAL RISK'
      };
    } else if (suspicionCategory === 'Potentially Suspicious') {
      return {
        icon: AlertTriangle,
        color: 'yellow',
        bgGradient: 'from-yellow-950/50 to-yellow-900/30',
        borderColor: 'border-yellow-900/50',
        iconColor: 'text-yellow-400',
        textColor: 'text-yellow-300',
        scoreColor: 'text-yellow-400',
        label: 'MEDIUM RISK'
      };
    } else {
      return {
        icon: CheckCircle,
        color: 'green',
        bgGradient: 'from-green-950/50 to-green-900/30',
        borderColor: 'border-green-900/50',
        iconColor: 'text-green-400',
        textColor: 'text-green-300',
        scoreColor: 'text-green-400',
        label: 'LOW RISK'
      };
    }
  };

  const config = getRiskConfig();
  const Icon = config.icon;
  const probabilityPercent = (suspicionProbability * 100).toFixed(1);

  return (
    <div className={`bg-gradient-to-br ${config.bgGradient} border ${config.borderColor} rounded-xl p-6`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 flex-1">
          <div className={`p-3 bg-slate-900/50 rounded-lg`}>
            <Icon className={`w-8 h-8 ${config.iconColor}`} />
          </div>
          
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className={`text-xs ${config.textColor} px-2 py-1 rounded bg-slate-900/50`}>
                {config.label}
              </span>
            </div>
            <h2 className="text-slate-100 mb-1">
              {companyName} ({ticker})
            </h2>
            <p className={`${config.textColor}`}>
              Suspicion Category: {suspicionCategory}
            </p>
          </div>
        </div>

        <div className="text-right">
          <p className="text-slate-400 mb-1">Suspicion Score</p>
          <p className={`text-4xl ${config.scoreColor}`}>
            {probabilityPercent}%
          </p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mt-6">
        <div className="flex justify-between text-xs text-slate-400 mb-2">
          <span>Not Suspicious</span>
          <span>Potentially Suspicious</span>
          <span>Highly Suspicious</span>
        </div>
        <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
          <div 
            className={`h-full transition-all duration-500 ${
              suspicionCategory === 'Highly Suspicious' 
                ? 'bg-gradient-to-r from-red-600 to-red-500' 
                : suspicionCategory === 'Potentially Suspicious'
                ? 'bg-gradient-to-r from-yellow-600 to-yellow-500'
                : 'bg-gradient-to-r from-green-600 to-green-500'
            }`}
            style={{ width: `${suspicionProbability * 100}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-slate-500 mt-1">
          <span>0%</span>
          <span>50%</span>
          <span>80%</span>
          <span>100%</span>
        </div>
      </div>
    </div>
  );
}
