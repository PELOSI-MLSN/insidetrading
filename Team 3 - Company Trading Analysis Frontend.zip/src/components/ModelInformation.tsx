import { Brain, Database, Target, TrendingUp, BarChart3, Info } from 'lucide-react';
import { useState } from 'react';

export function ModelInformation() {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-xl p-6">
      <div 
        className="flex items-center justify-between cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/10 rounded-lg">
            <Brain className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <h3 className="text-slate-100">About This Model</h3>
            <p className="text-slate-400 text-sm">XGBoost-based insider trading detection</p>
          </div>
        </div>
        <button className="text-slate-400 hover:text-slate-300">
          {isExpanded ? '−' : '+'}
        </button>
      </div>

      {isExpanded && (
        <div className="mt-6 space-y-6">
          {/* Plain Language Explanation */}
          <div className="bg-slate-800/50 rounded-lg p-5 border border-slate-700">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-slate-200 mb-2">How It Works (Plain Language)</h4>
                <p className="text-slate-400 text-sm leading-relaxed mb-3">
                  This system uses <span className="text-blue-400">XGBoost</span>, a powerful machine learning algorithm, 
                  to detect suspicious insider trading patterns. Think of it as an experienced analyst who has reviewed 
                  thousands of insider trades and learned to spot unusual patterns.
                </p>
                <p className="text-slate-400 text-sm leading-relaxed">
                  The model examines multiple features of each trade—like how large the trade is relative to what the 
                  insider already owns, the trade direction, price changes, and timing—and combines them to produce a 
                  suspicion score. It doesn't just look at one red flag; it considers the entire context.
                </p>
              </div>
            </div>
          </div>

          {/* Training Process */}
          <div>
            <h4 className="text-slate-200 mb-3">Training Process</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-slate-800 rounded-lg flex-shrink-0">
                  <Database className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <p className="text-slate-300 mb-1">1. Data Collection</p>
                  <p className="text-slate-500 text-sm">
                    Historical SEC Form 4 filings containing insider trading data are collected and cleaned. 
                    Columns include trade date, ticker, price, quantity, owned shares, trade type, and ownership changes.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 bg-slate-800 rounded-lg flex-shrink-0">
                  <TrendingUp className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <p className="text-slate-300 mb-1">2. Feature Engineering</p>
                  <p className="text-slate-500 text-sm">
                    Key features are calculated automatically:
                    <span className="block mt-1 text-purple-400">
                      • Trade Size Relative to Owned (qty / (owned + qty))
                    </span>
                    <span className="block text-purple-400">
                      • Change in Ownership (δown = qty / owned × 100)
                    </span>
                    <span className="block text-purple-400">
                      • Trade Direction (Buy, Sell, Other based on trade type)
                    </span>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 bg-slate-800 rounded-lg flex-shrink-0">
                  <BarChart3 className="w-4 h-4 text-yellow-400" />
                </div>
                <div>
                  <p className="text-slate-300 mb-1">3. XGBoost Training</p>
                  <p className="text-slate-500 text-sm">
                    The model is trained using XGBoost with a binary classification objective. It learns to 
                    distinguish between normal trading patterns and potentially suspicious ones by building 
                    an ensemble of decision trees that vote on the final prediction.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 bg-slate-800 rounded-lg flex-shrink-0">
                  <Target className="w-4 h-4 text-red-400" />
                </div>
                <div>
                  <p className="text-slate-300 mb-1">4. Evaluation & Thresholds</p>
                  <p className="text-slate-500 text-sm">
                    The model outputs a probability score (0-100%). Thresholds are calibrated:
                    <span className="block mt-1 text-red-400">• {'>'}80%: Highly Suspicious</span>
                    <span className="block text-yellow-400">• 50-80%: Potentially Suspicious</span>
                    <span className="block text-green-400">• {'<'}50%: Not Suspicious</span>
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Key Features */}
          <div className="bg-blue-950/20 border border-blue-900/30 rounded-lg p-4">
            <h4 className="text-blue-300 mb-2">Input Features Used</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <span className="text-slate-400">✓ Price per share</span>
              <span className="text-slate-400">✓ Quantity traded</span>
              <span className="text-slate-400">✓ Shares currently owned</span>
              <span className="text-slate-400">✓ Trade value</span>
              <span className="text-slate-400">✓ Change in ownership (δown)</span>
              <span className="text-slate-400">✓ Trade size relative to owned</span>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="bg-amber-950/20 border border-amber-900/30 rounded-lg p-4">
            <p className="text-amber-300 text-sm">
              <strong>Important:</strong> This model is a detection tool, not a legal judgment. 
              A high suspicion score indicates unusual patterns that warrant further investigation, 
              but does not prove illegal activity. Always consult with legal and compliance experts.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}