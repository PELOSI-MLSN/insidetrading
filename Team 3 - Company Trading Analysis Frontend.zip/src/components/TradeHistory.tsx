import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle } from 'lucide-react';
import type { TradeData, AnalysisResult } from '../App';

interface TradeHistoryProps {
  trades: Array<TradeData & { analysis: AnalysisResult }>;
}

export function TradeHistory({ trades }: TradeHistoryProps) {
  if (trades.length === 0) {
    return (
      <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-xl p-6">
        <h3 className="text-slate-100 mb-4">Recent Submissions</h3>
        <div className="text-center py-8">
          <p className="text-slate-500">No trades analyzed yet</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-xl p-6">
      <h3 className="text-slate-100 mb-4">Recent Submissions</h3>
      
      <div className="space-y-3">
        {trades.map((trade) => {
          const isBuy = trade.analysis.calculatedFeatures.tradeDirection === 'Buy';
          const probability = (trade.analysis.suspicionProbability * 100).toFixed(0);
          
          const getRiskIcon = () => {
            if (trade.analysis.suspicionCategory === 'Highly Suspicious') {
              return <AlertTriangle className="w-4 h-4 text-red-400" />;
            } else if (trade.analysis.suspicionCategory === 'Potentially Suspicious') {
              return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
            } else {
              return <CheckCircle className="w-4 h-4 text-green-400" />;
            }
          };

          const getRiskColor = () => {
            if (trade.analysis.suspicionCategory === 'Highly Suspicious') {
              return 'border-red-900/50 bg-red-950/20';
            } else if (trade.analysis.suspicionCategory === 'Potentially Suspicious') {
              return 'border-yellow-900/50 bg-yellow-950/20';
            } else {
              return 'border-green-900/50 bg-green-950/20';
            }
          };

          return (
            <div 
              key={trade.id} 
              className={`border rounded-lg p-4 ${getRiskColor()}`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-slate-100">
                      {trade.companyName}
                    </span>
                    <span className="text-slate-500">({trade.ticker})</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-slate-400">
                    <span>{trade.tradeDate}</span>
                    <span className="flex items-center gap-1">
                      {isBuy ? (
                        <TrendingUp className="w-3 h-3 text-green-400" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-red-400" />
                      )}
                      {Math.abs(trade.qty).toLocaleString()} shares
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  {getRiskIcon()}
                  <span className={`text-sm ${
                    trade.analysis.suspicionCategory === 'Highly Suspicious' 
                      ? 'text-red-400' 
                      : trade.analysis.suspicionCategory === 'Potentially Suspicious'
                      ? 'text-yellow-400'
                      : 'text-green-400'
                  }`}>
                    {probability}%
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-4 text-sm text-slate-400">
                <span>
                  ${trade.price.toFixed(2)} per share
                </span>
                <span>
                  Value: ${trade.analysis.calculatedFeatures.value.toLocaleString()}
                </span>
              </div>

              {trade.insiderName && (
                <div className="mt-2 pt-2 border-t border-slate-700 text-sm text-slate-500">
                  {trade.insiderName}
                  {trade.insiderTitle && ` • ${trade.insiderTitle}`}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
