import { useState } from 'react';
import { TradeInputForm } from './components/TradeInputForm';
import { SuspicionResult } from './components/SuspicionResult';
import { FeatureBreakdown } from './components/FeatureBreakdown';
import { TradeHistory } from './components/TradeHistory';
import { ModelInformation } from './components/ModelInformation';
import { CounterfactualExplanation } from './components/CounterfactualExplanation';
import { Shield, AlertTriangle } from 'lucide-react';

export interface TradeData {
  id: string;
  companyName: string;
  ticker: string;
  price: number;
  qty: number;
  owned: number;
  tradeType: string;
  tradeDate: string;
  insiderName?: string;
  insiderTitle?: string;
}

export interface AnalysisResult {
  suspicionProbability: number;
  suspicionCategory: 'Highly Suspicious' | 'Potentially Suspicious' | 'Not Suspicious';
  calculatedFeatures: {
    tradeSizeRelativeToOwned: number;
    tradeDirection: string;
    value: number;
    changeInOwnership: number;
  };
  featureContributions: Array<{
    name: string;
    value: string | number;
    contribution: number;
  }>;
}

export default function App() {
  const [tradeHistory, setTradeHistory] = useState<Array<TradeData & { analysis: AnalysisResult }>>([]);
  const [currentAnalysis, setCurrentAnalysis] = useState<AnalysisResult | null>(null);
  const [currentTrade, setCurrentTrade] = useState<TradeData | null>(null);

  const handleTradeSubmit = (tradeData: TradeData) => {
    // Calculate derived features
    const analysis = analyzeTrade(tradeData);
    
    // Add to history
    setTradeHistory(prev => [{ ...tradeData, analysis }, ...prev].slice(0, 10));
    setCurrentAnalysis(analysis);
    setCurrentTrade(tradeData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <Shield className="w-8 h-8 text-blue-400" />
            </div>
            <div>
              <h1 className="text-slate-100">Insider Trading Detection System</h1>
              <p className="text-slate-400">AI-powered suspicious activity monitoring with XGBoost</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Model Information */}
        <ModelInformation />

        {/* Input Section */}
        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800 rounded-xl p-6">
          <h2 className="text-slate-100 mb-4">Enter Trade Details</h2>
          <TradeInputForm onSubmit={handleTradeSubmit} />
        </div>

        {/* Results Section */}
        {currentAnalysis && currentTrade ? (
          <>
            <SuspicionResult 
              companyName={currentTrade.companyName}
              ticker={currentTrade.ticker}
              suspicionProbability={currentAnalysis.suspicionProbability}
              suspicionCategory={currentAnalysis.suspicionCategory}
            />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <FeatureBreakdown 
                calculatedFeatures={currentAnalysis.calculatedFeatures}
                featureContributions={currentAnalysis.featureContributions}
                tradeData={currentTrade}
              />
              <TradeHistory trades={tradeHistory} />
            </div>

            {/* Counterfactual Explanation */}
            <CounterfactualExplanation 
              tradeData={currentTrade}
              analysis={currentAnalysis}
            />

            {/* Alert Banner */}
            {currentAnalysis.suspicionCategory === 'Highly Suspicious' && (
              <div className="bg-red-950/30 border border-red-900/50 rounded-xl p-6">
                <div className="flex gap-4">
                  <AlertTriangle className="w-6 h-6 text-red-400 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-red-300 mb-2">High Risk Alert</h3>
                    <p className="text-slate-300">
                      This trade has been flagged as highly suspicious (probability {'>'} 0.80). 
                      Consider further investigation and compliance review. This system is for 
                      detection purposes only and does not constitute legal advice.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {currentAnalysis.suspicionCategory === 'Potentially Suspicious' && (
              <div className="bg-yellow-950/30 border border-yellow-900/50 rounded-xl p-6">
                <div className="flex gap-4">
                  <AlertTriangle className="w-6 h-6 text-yellow-400 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-yellow-300 mb-2">Medium Risk Notice</h3>
                    <p className="text-slate-300">
                      This trade shows potentially suspicious patterns (probability 0.50-0.80). 
                      Review the feature contributions and trade context for further assessment.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-20">
            <div className="inline-block p-4 bg-slate-800/50 rounded-full mb-4">
              <Shield className="w-12 h-12 text-slate-600" />
            </div>
            <h2 className="text-slate-400 mb-2">No Trade Analyzed</h2>
            <p className="text-slate-500">
              Enter trade details above to analyze insider trading patterns
            </p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 mt-12 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-slate-500">
            Powered by XGBoost ML Model • Features: Price, Quantity, Ownership, Trade Direction
          </p>
        </div>
      </footer>
    </div>
  );
}

function analyzeTrade(tradeData: TradeData): AnalysisResult {
  // Calculate derived features
  const tradeSizeRelativeToOwned = Math.abs(tradeData.qty) / (tradeData.owned + Math.abs(tradeData.qty));
  const value = tradeData.price * Math.abs(tradeData.qty);
  const changeInOwnership = (tradeData.qty / tradeData.owned) * 100;
  
  // Determine trade direction
  let tradeDirection = 'Other';
  if (tradeData.tradeType.includes('Purchase') || tradeData.tradeType.includes('OptEx')) {
    tradeDirection = 'Buy';
  } else if (tradeData.tradeType.includes('Sale') || tradeData.tradeType.includes('Tax')) {
    tradeDirection = 'Sell';
  }

  // Mock ML model prediction (in real app, this would call the backend)
  // Calculate suspicion based on various factors
  let suspicionScore = 0.5;
  
  // High trade size relative to owned increases suspicion
  if (tradeSizeRelativeToOwned > 0.5) suspicionScore += 0.15;
  if (tradeSizeRelativeToOwned > 0.7) suspicionScore += 0.1;
  
  // Large absolute ownership change
  if (Math.abs(changeInOwnership) > 30) suspicionScore += 0.1;
  if (Math.abs(changeInOwnership) > 50) suspicionScore += 0.05;
  
  // Very high or very low prices can be suspicious
  if (tradeData.price > 500 || tradeData.price < 5) suspicionScore += 0.08;
  
  // Large quantities
  if (Math.abs(tradeData.qty) > 100000) suspicionScore += 0.07;
  
  // Sales are generally more scrutinized
  if (tradeDirection === 'Sell') suspicionScore += 0.05;
  
  // Add some randomness to simulate model uncertainty
  suspicionScore = Math.min(0.95, Math.max(0.05, suspicionScore + (Math.random() - 0.5) * 0.15));

  // Determine category
  let suspicionCategory: 'Highly Suspicious' | 'Potentially Suspicious' | 'Not Suspicious';
  if (suspicionScore > 0.8) {
    suspicionCategory = 'Highly Suspicious';
  } else if (suspicionScore >= 0.5) {
    suspicionCategory = 'Potentially Suspicious';
  } else {
    suspicionCategory = 'Not Suspicious';
  }

  // Feature contributions (mock values based on importance)
  const featureContributions = [
    { 
      name: 'Trade Size Relative to Owned', 
      value: (tradeSizeRelativeToOwned * 100).toFixed(1) + '%',
      contribution: tradeSizeRelativeToOwned * 0.25 
    },
    { 
      name: 'Trade Direction', 
      value: tradeDirection,
      contribution: tradeDirection === 'Sell' ? 0.18 : 0.12 
    },
    { 
      name: 'Change in Ownership', 
      value: changeInOwnership.toFixed(1) + '%',
      contribution: Math.min(Math.abs(changeInOwnership) / 100, 0.2) 
    },
    { 
      name: 'Trade Value', 
      value: '$' + value.toLocaleString(),
      contribution: Math.min(value / 10000000, 0.15) 
    },
    { 
      name: 'Price', 
      value: '$' + tradeData.price.toFixed(2),
      contribution: 0.12 
    },
    { 
      name: 'Quantity', 
      value: Math.abs(tradeData.qty).toLocaleString(),
      contribution: Math.min(Math.abs(tradeData.qty) / 500000, 0.1) 
    }
  ].sort((a, b) => b.contribution - a.contribution);

  return {
    suspicionProbability: suspicionScore,
    suspicionCategory,
    calculatedFeatures: {
      tradeSizeRelativeToOwned,
      tradeDirection,
      value,
      changeInOwnership
    },
    featureContributions
  };
}