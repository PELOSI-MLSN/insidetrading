
  # Team 3 - Company Trading Analysis Frontend

  This is a code bundle for Team 3 - Company Trading Analysis Frontend. The original project is available at https://www.figma.com/design/jR1noIirnMkxTCULrVb4HR/Team-3---Company-Trading-Analysis-Frontend.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  